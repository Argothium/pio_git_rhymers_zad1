# Laboratoria - git, github, jakość kodu i refaktoryzacja

## instrukcje

Repozytorium zawiera początkową wersje projektu przetwarzanego w trakcie laboratoriów 
realizowanych w ramach przedmiotu 'Podstawy Inżynierii Oprogramowania' prowadzonego 
przez Instytut Informatyki Stosowanej dla studentów kierunku Informatyka 
na wydziale Elektrotechniki, Elektroniki Informatyki i Automatyki Politechniki Łódzkiej.

## wybrane materiały i dodatkowe informacje

- [WIKI projektu z opisem dodatkowych zadań oraz sposobu realizacji pracy](https://github.com/iis-io-team/pio_git_rhymers/wiki)
